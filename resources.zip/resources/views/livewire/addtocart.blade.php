<div>
    {{-- Close your eyes. Count to one. That is how long forever feels. --}}
    <button type="button" wire:click="clickEvt" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">{{ $msg }}</button>

</div>
