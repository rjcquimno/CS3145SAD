    <tr class="font-bold text-center">
        <td></td>
        <td ></td>
        <td ></td>
        <td class="border-2 border-black">Grand Total</td>
        <input type="hidden" name="order_discount" value="{{$totaldiscount}}" class="text-center" readonly>
        <td class="border-2 border-black"><input type="text" name="order_total" value="{{$msg}}" class="text-center" readonly></td>
    
    </tr>

