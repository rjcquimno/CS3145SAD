    <tr class="font-bold text-center">
        @if ($show)
        <td></td>
        <td ></td>
        <td ></td>
        <td class="border-2 border-black">VATS</td>
        <input type="hidden" name="order_senior_discount" value="0" class="text-center" readonly>
        <td class="border-2 border-black"><input type="text" value="{{$subtotal}}" class="text-center" readonly></td>
        @endif 
    </tr>

