    <tr class="font-bold text-center">
        
        <td></td>
        <td ></td>
        <td ></td>
        <td class="border-2 border-black">Subtotal</td>

        <td class="border-2 border-black">{{$subtotal}}</td>
    
    </tr>

