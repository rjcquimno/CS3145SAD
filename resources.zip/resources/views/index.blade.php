<x-layout>
    @include('partials._hero')
</x-layout>

    
    
    
    
    